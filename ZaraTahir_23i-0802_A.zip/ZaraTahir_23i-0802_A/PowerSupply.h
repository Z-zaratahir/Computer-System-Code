#pragma once
#include <iostream>
using namespace std;

class PowerSupply
{

    int wattage;
    string efficiencyRating;
    double price;

public:
    PowerSupply()
        : wattage(0),
        efficiencyRating(" "),
        price(0.0) {}

    PowerSupply(int myWattage, string myEfficiencyRating, double myPrice)
        : wattage(myWattage),
        efficiencyRating(myEfficiencyRating),
        price(myPrice) {}

    int GetWattage()
    {
        return wattage;
    }

    void SetWattage(int myWattage)
    {
        wattage = myWattage;
    }

    string GetEfficiencyRating()
    {

        return efficiencyRating;
    }

    void SetEfficiencyRating(string myEfficiencyRating)
    {

        efficiencyRating = myEfficiencyRating;
    }

    double GetPrice()
    {
        return price;
    }

    void SetPrice(double myPrice)
    {

        price = myPrice;
    }

    void InputPowerSupply()
    {
        cout << "\nEnter the wattage of the power supply (300 - 750) W: ";


        //invalid input
        while (!(cin >> wattage) || wattage < 300 || wattage > 750)
        {
            cout << "Invalid input! Please enter a valid input...  ";
            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n')// discards data until \n
            {
                continue;
            }

        }

        bool flag = false;
        while (!flag)
        {
            cout << "\nSelect one form the following efficiency ratings of the power supply:" << endl;

            cout << "1. 80 Plus Bronze" << endl;

            cout << "2. 80 Plus Gold" << endl;

            int picked;
            cout << "\nSelecting: ";

            // if the input is an alphabet
            if (!(cin >> picked))
            {
                cout << "\nInvalid input! Please enter an integer not an alphabet...\n";

                cin.clear(); // clears the inputted data for new data to get inputted

                while (cin.get() != '\n') // discards data until \n
                {
                    continue; // continues tll it reaches a \n
                }

                continue; // for inputting again
            }

            switch (picked)
            {
            case 1:
                efficiencyRating = "80 Plus Bronze";
                price = 80.0;
                flag = true;
                break;

            case 2:
                efficiencyRating = "80 Plus Gold";
                price = 120.0;
                flag = true;
                break;

            default:
                cout << "Invalid choice. Please choose a valid option." << endl;
                break;
            }
        }

        // cout << "\nEnter the price of the power supply: $";
        // cin >> price;
    }


    void InputPowerSupplyForMac()
    {
        cout << "\nPOWER SUPPLY: \n-------------\n";
        cout << "\nEnter the wattage of the power supply (30 - 300) W: ";


        //invalid input
        while (!(cin >> wattage) || wattage < 30 || wattage > 300)
        {
            cout << "Invalid input! Please enter a valid input...  ";
            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n')// discards data until \n
            {
                continue;
            }

        }

        bool flag = false;
        while (!flag)
        {
            cout << "\nSelect one form the following efficiency ratings of the power supply:" << endl;

            cout << "1. 80 Plus Bronze" << endl;

            cout << "2. 80 Plus Gold" << endl;

            int picked;
            cout << "\nSelecting: ";

            // if the input is an alphabet
            if (!(cin >> picked))
            {
                cout << "\nInvalid input! Please enter an integer not an alphabet...\n";

                cin.clear(); // clears the inputted data for new data to get inputted

                while (cin.get() != '\n') // discards data until \n
                {
                    continue; // continues tll it reaches a \n
                }

                continue; // for inputting again
            }

            switch (picked)
            {
            case 1:
                efficiencyRating = "80 Plus Bronze";
                price = 80.0;
                flag = true;
                break;

            case 2:
                efficiencyRating = "80 Plus Gold";
                price = 120.0;
                flag = true;
                break;

            default:
                cout << "Invalid choice. Please choose a valid option." << endl;
                break;
            }
        }

        // cout << "\nEnter the price of the power supply: $";
        // cin >> price;
    }


    void DisplayPOwerSuppy()
    {
        cout << "\nPOWER SUPPLY DETAILS: \n-------------\n\n";

        cout << "\nWattage: " << wattage << " W" << endl;

        cout << "Efficiency Rating: " << efficiencyRating << endl;

        // cout << "Price: $" << price << endl;
    }
};
