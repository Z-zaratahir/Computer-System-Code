#pragma once
#include <iostream>
using namespace std;

class NetworkCard
{

    string type;
    int speed;
    double price;

public:
    NetworkCard()
        : type(" "),
        speed(0),
        price(0.0) {}

    NetworkCard(string myType, int mySpeed, double myPrice)
        : type(myType),
        speed(mySpeed),
        price(myPrice) {}

    string GetType()
    {
        return type;
    }

    void SetType(string myType)
    {
        type = myType;
    }

    int GetSpeed()
    {
        return speed;
    }

    void GetSpeed(int mySpeed)
    {

        speed = mySpeed;
    }

    double GetPrice()
    {
        return price;
    }

    void SetPrice(double myPrice)
    {

        price = myPrice;
    }

    void InputNetworkCards()
    {
        cout << "\nNETWORK CARD: \n-------------\n";
        bool flag = false;

        int picked;
        while (true)
        {
            cout << "\nSelect the type of network card:" << endl;

            cout << "1. Ethernet" << endl;

            cout << "2. WiFi" << endl;

            cout << "\nSelecting: ";


            // if the input is an alphabet
            if (!(cin >> picked))
            {
                cout << "\nInvalid input! Please enter an integer not an alphabet...\n";

                cin.clear(); // clears the inputted data for new data to get inputted

                while (cin.get() != '\n') // discards data until \n
                {
                    continue; // continues tll it reaches a \n
                }

                continue; // for inputting again
            }

            switch (picked)
            {
            case 1:
                type = "Ethernet";
                price = 50.0;
                flag = true;
                break;
            case 2:
                type = "WiFi";
                price = 50.0;
                flag = true;
                break;
            default:
                cout << "Invalid choice! Please enter either 1 or 2.\n"
                    << endl;
                break;
            }

            if (flag)
            {
                break;
            }
        }

        cout << "\nEnter the speed of the network card (10/100/1000/10000) Mbps: ";
        cin >> speed;

        // invalid input
        while (speed != 10 && speed != 100 && speed != 1000 && speed != 10000)
        {
            cout << "Invalid input! Please enter a valid input...  ";
            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n');// discards data until \n

            cin >> speed;
        }

        // cout << "\nEnter the price of the network card: $";
        // cin >> price;
    }

    void DisplayNetworkCards()
    {

        cout << "\nNETWORK CARD DETAILS: \n-------------\n\n";
        cout << "Type: " << type << endl;

        cout << "Speed: " << speed << " Mbps" << endl;

        // cout << "Price: $" << price << endl;
    }
};
