#pragma once
#include "../oop_a3/IntelAMD.h"

using namespace std;

class LAPTOPS : public IntelAMD
{
public:

    LAPTOPS() :IntelAMD() {}

};