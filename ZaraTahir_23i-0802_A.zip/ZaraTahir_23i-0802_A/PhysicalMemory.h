#pragma once
#include <iostream>
using namespace std;

class PhysicalMemory
{

protected:
    int capacity;

public:
    PhysicalMemory()
        : capacity(0) {}

    PhysicalMemory(int Capacity)
        : capacity(Capacity) {}

    int GetCapacity()
    {

        return capacity;
    }

    void SetCapacity(int Capacity)
    {

        capacity = Capacity;
    }

    void InputPhysicalMemory()
    {
        cout << "\n\n---PHYSICAL MEMORY REQUIREMENTS---\n\n";

        cout << "\nEnter the capacity of physical memory using DDR 4/5 (4/8/32/64/128): ";
        cin >> capacity;

        //invalid input
        while (capacity != 64 && capacity != 4 && capacity != 8 && capacity != 128 && capacity != 32)
        {
            cout << "Invalid input! Please enter a valid input...  ";
            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n');// discards data until \n

            cin >> capacity;
        }

    }

    void InputPhysicalMemoryForMac()
    {
        cout << "\n\n---PHYSICAL MEMORY REQUIREMENTS---\n\n";

        cout << "\nEnter the capacity of physical memory using LPDDR 4/5 (4/8/16/32): ";
        cin >> capacity;

        //invalid input
        while (capacity != 4 && capacity != 8 && capacity != 16 && capacity != 32)
        {
            cout << "Invalid input! Please enter a valid input...  ";
            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n');// discards data until \n

            cin >> capacity;
        }
    }

    void DisplayPhysicalMemory()
    {
        cout << "\nPHYSICAL MEMORY DETAILS: \n-------------\n";
        cout << "\nThe capacity of physical memory is: " << capacity << endl;
    }
};
