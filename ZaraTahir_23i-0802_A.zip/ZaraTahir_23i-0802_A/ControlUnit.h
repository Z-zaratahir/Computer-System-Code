#pragma once
#include <iostream>
using namespace std;


class ControlUnit
{
private:
    float clock;

public:
    ControlUnit()
        : clock(0.0) {}
    ControlUnit(float theClock)
        : clock(theClock) {}

    float getclock()
    {
        return clock;
    }

    void setclock(float theClock)
    {

        clock = theClock;
    }

    void inputClock()
    {
        cout << "\nCONTROL UNIT:\n";
        cout << "-------------\n";
        cout << "\nEnter the clock speed (1.0 GHz - 4.0 GHz):  ";
        //  cin >> clock;

          //invalid input
        while (!(cin >> clock) || clock < 1 || clock > 4)
        {
            cout << "Invalid input! Please enter a valid input...  ";
            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n')// discards data until \n
            {
                continue;
            }
            // cin >> clock;
        }
    }

    void inputClockForMac()
    {
        cout << "\nCONTROL UNIT:\n";
        cout << "-------------\n";
        cout << "\nEnter the clock speed (1.0 GHz - 5.0 GHz):  ";
        // cin >> clock;

         //invalid input
        while (!(cin >> clock) || clock < 1 || clock > 5)
        {
            cout << "Invalid input! Please enter a valid input...  ";
            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n')// discards data until \n
            {
                continue;
            }
            // cin >> clock;
        }
    }

    void displayclock()
    {
        cout << "\n\nCONTROL UNIT DETAILS: \n";
        cout << "-------------\n";
        cout << "\nClock speed: " << clock << " GHz" << endl;
    }
};
