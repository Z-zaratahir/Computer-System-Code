#pragma once
#include "../oop_a3/APPLE.h"

using namespace std;

class IPAD : public APPLE
{
public:

    IPAD() :APPLE() {}

};