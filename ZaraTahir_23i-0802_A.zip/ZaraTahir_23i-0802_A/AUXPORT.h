#pragma once
#include "../oop_a3/Port.h"

class AUXPORT : public Port
{
public:
    AUXPORT() : Port(0.0, " ", 0) {}


    AUXPORT(double myPrice, string myType, int myBaudRate)
        : Port(myPrice, myType, myBaudRate) {}
};