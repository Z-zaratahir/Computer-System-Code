#pragma once
#include "../oop_a3/Port.h"

class InputOutput : public Port
{
public:
    InputOutput() : Port(0.0, " ", 0) {}


    InputOutput(double myPrice, string myType, int myBaudRate)
        : Port(myPrice, myType, myBaudRate) {}
};