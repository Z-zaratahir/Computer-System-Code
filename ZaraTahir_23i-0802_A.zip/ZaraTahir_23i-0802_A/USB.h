#pragma once
#include "../oop_a3/Port.h"

class USB : public Port
{
public:
    USB() : Port(0.0, " ", 0) {}


    USB(double myPrice, string myType, int myBaudRate)
        : Port(myPrice, myType, myBaudRate) {}
};