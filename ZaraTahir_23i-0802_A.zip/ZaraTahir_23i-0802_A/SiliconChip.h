#pragma once
#include "../oop_a3/CPU.h"


class SiliconChip : public CPU
{
    string architecture;

public:
    SiliconChip() : architecture(" ") {}

    SiliconChip(int NoOfAdders, int NoOfSubtractor, int NoOfRegisters,
        int sizeOfRegisters, double price, float theClock, string myArchitecture)
        : CPU(NoOfAdders, NoOfSubtractor, NoOfRegisters,
            sizeOfRegisters, price, theClock),
        architecture(myArchitecture) {}

    // SiliconChip(string myArchitecture)
    //     : architecture(myArchitecture) {}

    string getArchitecture()
    {

        return architecture;
    }
    void setArchitecture(string myArchitecture)
    {
        architecture = myArchitecture;
    }

    void DisplayArchitectureForAPPLE()
    {
        cout << "\nArchitecture: ARM64\n";
    }
    void DisplayArchitectureForINTEL()
    {
        cout << "\nArchitecture: x86\n";
    }
};