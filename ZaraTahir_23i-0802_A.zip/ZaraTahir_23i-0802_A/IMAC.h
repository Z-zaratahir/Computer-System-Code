#pragma once
#include "../oop_a3/APPLE.h"

using namespace std;

class IMAC : public APPLE
{
public:

    IMAC() :APPLE() {}

};