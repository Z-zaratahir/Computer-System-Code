#pragma once
#include <iostream>
#include <string>
using namespace std;

class GraphicsCard
{

    string brand;
    int memorySize;
    double price = 500.0;

public:
    GraphicsCard()
        : brand(" "),
        memorySize(0),
        price(500.0) {}

    GraphicsCard(string myBrand, int myMemorySize, double myPrice)
        : brand(myBrand),
        memorySize(myMemorySize),
        price(myPrice) {}

    string GetBrand()
    {

        return brand;
    }

    void SetBrand(string myBrand)
    {

        brand = myBrand;
    }

    int GetMemorySize()
    {
        return memorySize;
    }

    void SetMemorySize(int myMemorySize)
    {

        memorySize = myMemorySize;
    }

    double GetPrice()
    {
        return price;
    }

    void SetPrice(double myPrice = 500.0)
    {

        price = myPrice;
    }

    void InputGraphicsCard()
    {
        cout << "\nGRAPHIC CARD: \n-------------\n";


        bool flag = false;
        int picked;

        while (true)
        {

            cout << "\nSelect one of the following brand names for graphic cards: " << endl
                << endl;
            cout << "1. NVIDIA" << endl;
            cout << "2. AMD" << endl;
            cout << "3. ASUS" << endl;
            cout << "4. Gigabyte" << endl;
            cout << "5. Others (Pick this option and input your desired brand)" << endl
                << endl;

            cout << "\nSelected: ";


            // if the input is an alphabet
            if (!(cin >> picked))
            {
                cout << "\nInvalid input! Please enter an integer not an alphabet...\n";

                cin.clear(); // clears the inputted data for new data to get inputted

                while (cin.get() != '\n') // discards data until \n
                {
                    continue; // continues tll it reaches a \n
                }

                continue; // for inputting again
            }

            switch (picked)
            {

            case 1:
                brand = "NVIDIA";
                flag = true;
                break;

            case 2:
                brand = "AMD";
                flag = true;
                break;

            case 3:
                brand = "ASUS";
                flag = true;
                break;

            case 4:
                brand = "Gigabyte";
                flag = true;
                break;

            case 5:
                cout << "\nEnter the brand name of the graphics card:  ";
                cin.ignore();
                getline(cin, brand);
                flag = true;
                break;



            default:
                cout << "It's an invalid choice...Please choose a valid option." << endl;
                break;
            }

            if (flag)
            {
                break;
            }
        }




        cout << "\nEnter the memory size of the graphics card (2/4/8/16) GB:  ";
        cin >> memorySize;

        // invalid input
        while (memorySize != 2 && memorySize != 4 && memorySize != 8 && memorySize != 16)
        {
            cout << "Invalid input! Please enter a valid input...  ";
            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n');// discards data until \n

            cin >> memorySize;
        }

        // cout << "\nEnter the price of the graphics card:  $";
        // cin >> price;
    }

    void DisplayGraphicsCard()
    {
        cout << "\nGRAPHIC CARD DETAILS: \n-------------\n\n";

        cout << "Brand Name: " << brand << endl;

        cout << "Memory Size: " << memorySize << " GB" << endl;

        // cout << "Price: $" << price << endl;
    }
};