#pragma once
#include <iostream>
using namespace std;


class ALU
{
private:
    int NoOfAdders;
    int NoOfSubtractor;
    int NoOfRegisters;
    int SizeOfRegisters;

public:
    ALU()
        : NoOfAdders(0),
        NoOfSubtractor(0),
        NoOfRegisters(0),
        SizeOfRegisters(0) {}

    ALU(int theAdders,
        int theSubtractor,
        int theRegisters,
        int sizeOfRegister)

        : NoOfAdders(theAdders),
        NoOfSubtractor(theSubtractor),
        NoOfRegisters(theRegisters),
        SizeOfRegisters(sizeOfRegister)
    {
    }

    int getNoOfAdders()
    {
        return NoOfAdders;
    }

    void setNoOfAdders(int NoOfAdders)
    {
        this->NoOfAdders = NoOfAdders;
    }

    int getNoOfSubtractor()
    {
        return NoOfSubtractor;
    }
    void setNoOfSubtractor(int NoOfSubtractor)
    {

        this->NoOfSubtractor = NoOfSubtractor;
    }

    int getNoOfRegisters()
    {
        return NoOfRegisters;
    }
    void setNoOfRegisters(int NoOfRegisters)
    {
        this->NoOfRegisters = NoOfRegisters;
    }

    int getSizeOfRegisters()
    {
        return SizeOfRegisters;
    }

    void setsizeOfRegisters(int SizeOfRegisters)
    {
        this->SizeOfRegisters = SizeOfRegisters;
    }

    void input()
    {
        cout << "ALU:\n";
        cout << "-------------\n";
        cout << "\nEnter the number of adders (8/16):  ";
        cin >> NoOfAdders;

        //invalid input
        while (NoOfAdders != 8 && NoOfAdders != 16)
        {
            cout << "Invalid input! Please enter a valid input...  ";
            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n');// discards data until \n

            cin >> NoOfAdders;
        }

        cout << "\nEnter the number of subtractors (8/16):  ";
        cin >> NoOfSubtractor;

        //invalid input
        while (NoOfSubtractor != 8 && NoOfSubtractor != 16)
        {
            cout << "Invalid input! Please enter a valid input...  ";
            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n');// discards data until \n

            cin >> NoOfSubtractor;
        }

        cout << "\nEnter the number of registers (8/16/32):  ";
        cin >> NoOfRegisters;

        //invalid input
        while (NoOfRegisters != 8 && NoOfRegisters != 16 && NoOfRegisters != 32)
        {
            cout << "Invalid input! Please enter a valid input...  ";
            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n');// discards data until \n

            cin >> NoOfRegisters;
        }

        cout << "\nEnter the size of registers (32/64/128/256/512):  ";
        cin >> SizeOfRegisters;

        //invalid input
        while (SizeOfRegisters != 32 && SizeOfRegisters != 64 && SizeOfRegisters != 256 && SizeOfRegisters != 128 && SizeOfRegisters != 512)
        {
            cout << "Invalid input! Please enter a valid input...  ";
            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n');// discards data until \n

            cin >> SizeOfRegisters;
        }
    }

    void InputForMac()
    {
        cout << "ALU:\n";
        cout << "-------------\n";
        cout << "\nEnter the number of adders (4/8):  ";
        cin >> NoOfAdders;

        //invalid input
        while (NoOfAdders != 8 && NoOfAdders != 4)
        {
            cout << "Invalid input! Please enter a valid input...  ";
            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n');// discards data until \n

            cin >> NoOfAdders;
        }

        cout << "\nEnter the number of subtractors (4/8):  ";
        cin >> NoOfSubtractor;

        // invalid input
        while (NoOfSubtractor != 8 && NoOfSubtractor != 4)
        {
            cout << "Invalid input! Please enter a valid input...  ";
            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n');// discards data until \n

            cin >> NoOfSubtractor;
        }


        cout << "\nEnter the number of registers(16/32):  ";
        cin >> NoOfRegisters;

        // invalid input
        while (NoOfRegisters != 16 && NoOfRegisters != 32)
        {
            cout << "Invalid input! Please enter a valid input...  ";
            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n');// discards data until \n

            cin >> NoOfRegisters;
        }

        cout << "\nEnter the size of registers (64/128/256):  ";
        cin >> SizeOfRegisters;


        //invalid input
        while (SizeOfRegisters != 64 && SizeOfRegisters != 128 && SizeOfRegisters != 256)
        {
            cout << "Invalid input! Please enter a valid input...  ";
            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n');// discards data until \n

            cin >> SizeOfRegisters;
        }


    }

    void displayALU()
    {
        cout << "ALU DETAILS: \n";
        cout << "-------------\n";
        cout << "\n Adders: " << NoOfAdders << " bits\n Subtractor: " << NoOfSubtractor << " bits\n Registers: " << NoOfRegisters << " bits\n Size of registers: " << SizeOfRegisters << " bits\n";
    }
};
