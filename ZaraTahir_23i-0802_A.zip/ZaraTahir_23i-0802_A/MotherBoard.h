#pragma once
#include <iostream>
#include "../oop_a3/MainMemory.h"
#include"../oop_a3/CPU.h"
#include "../oop_a3/Port.h"
#include "../oop_a3/GraphicsCard.h"
#include"../oop_a3/NetworkCard.h"
#include "../oop_a3/PhysicalMemory.h"
#include "../oop_a3/StorageDevice.h"
#include "../oop_a3/PowerSupply.h"
using namespace std;

class MotherBoard
{
private:
    MainMemory mm;
    CPU theCPU;
    Port* ports;
    int numOfPorts;
    GraphicsCard gpu;
    NetworkCard nc;
    PhysicalMemory pm;
    StorageDevice sd;
    PowerSupply* ps;

public:
    MotherBoard() : mm(MainMemory()), theCPU(CPU()), ports(nullptr), numOfPorts(0),
        gpu(GraphicsCard()), nc(NetworkCard()), pm(PhysicalMemory()),
        sd(StorageDevice()), ps(new PowerSupply()) {}

    double sumOfPrice()
    {

        double sum = 0.0;
        sum = theCPU.GetPrice() + mm.GetPrice() + ports->GetPrice() + gpu.GetPrice() + nc.GetPrice() + sd.GetPrice() + ps->GetPrice();

        return sum;
    }
    void InputMotherBoard()
    {
        // Input code for each component as needed
        theCPU.InputCPU();
        // PortsinMotherboard();
        cout << "\n\n---PORTS REQUIREMENTS---\n\n";
        cout << "Enter the number of ports: ";
        cin >> numOfPorts;

        if (numOfPorts > 0)
        {
            ports = new Port[numOfPorts];
            for (int i = 0; i < numOfPorts; i++)
            {
                cout << "\n  --> Port number " << i + 1 << ":\n";
                ports[i].InputPort();
            }
        }

        pm.InputPhysicalMemory();
        mm.InputMainMemory();
        sd.InputStorageDevice();
        gpu.InputGraphicsCard();
        nc.InputNetworkCards();
        ps->InputPowerSupply();
    }

    void InputMotherBoardForMac()
    {
        cout << "\n\n---MOTHERBOARD REQUIREMENTS---\n\n";
        // Calling for each component as needed
        theCPU.InputCPUForMac();
        cout << "\n\n---PORTS REQUIREMENTS---\n\n";

        cout << "Enter the number of ports: ";
        cin >> numOfPorts;

        if (numOfPorts > 0)
        {
            ports = new Port[numOfPorts];
            for (int i = 0; i < numOfPorts; i++)
            {
                cout << "Port number " << i + 1 << ":\n";
                ports[i].InputPort();
            }
        }

        pm.InputPhysicalMemoryForMac();
        mm.InputMainMemoryForMac();
        sd.InputStorageDeviceForMac();
        gpu.InputGraphicsCard();
        nc.InputNetworkCards();
        ps->InputPowerSupplyForMac();
    }

    void DisplayMotherBoard()
    {
        theCPU.DisplayCPU();
        cout << "\nPORT DETAILS: \n-------------\n";
        for (int i = 0; i < numOfPorts; i++)
        {
            ports[i].DisplayPorts();
        }
        pm.DisplayPhysicalMemory();
        mm.DisplayMainMemory();
        sd.DisplayStorageDevice();
        gpu.DisplayGraphicsCard();
        nc.DisplayNetworkCards();
        ps->DisplayPOwerSuppy();
    }

    ~MotherBoard()
    {
        delete[] ports;
        delete ps;
    }

    // private:
    //     void PortsinMotherboard()
    //     {
    //         // Input code for ports as before
    //     }
};