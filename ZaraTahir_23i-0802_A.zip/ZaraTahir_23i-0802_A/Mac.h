#pragma once
#include "../oop_a3/APPLE.h"

using namespace std;

class mac : public APPLE
{
public:

    mac() :APPLE() {}

};