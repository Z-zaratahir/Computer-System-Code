// Name              : Zara Tahir
// Section           : CS-A
// Roll number       : 23i-0802
// Instructor        : Dr. Ali Zeeshan
// Teacher Assistant : Muhammad Abdur Rafey
#include <iostream>
#include "C:\Users\win10pr\source\repos\oop_a3\oop_a3\Computer.h"
using namespace std;

int main()
{

    Computer comp;
    bool flag = false;
    int picked;

    cout << "\n                                                     WELCOME!\n";
    cout << "                                                   ------------\n\n";
    cout << "Do you want an Intel/AMD device or an Apple device?\n";
    cout << "Choose one from the following:\n\n";
    cout << "1. Intel/AMD - Architecture: x86\n";
    cout << "2. Apple - Architecture: ARM64\n\n";

    while (!flag)
    {
        cout << "Selecting:  ";

        // if the input is an alphabet
        if (!(cin >> picked))
        {
            cout << "\nInvalid input! Please enter an integer not an alphabet...\n";

            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n')// discards data until \n 
            {
                continue;// continues tll it reaches a \n
            }

            continue;// for inputting again
        }

        switch (picked)
        {
        case 1:// if the user chooses INTEL/AMD
        {
            bool flag2 = false;
            int Choice1;

            cout << "\nChoose one of the following Intel/AMD devices:\n";
            cout << "1. PC\n";
            cout << "2. Laptop\n";
            cout << "3. Phone\n";
            cout << "4. Tablet\n\n";

            while (!flag2)
            {
                cout << "Selecting:  ";


                // if the input is an alphabet
                if (!(cin >> Choice1))
                {
                    cout << "\nInvalid input! Please enter an integer not an alphabet...\n";

                    cin.clear(); // clears the inputted data for new data to get inputted

                    while (cin.get() != '\n') // discards data until \n
                    {
                        continue; // continues tll it reaches a \n
                    }

                    continue; // for inputting again
                }

                switch (Choice1)
                {
                case 1:
                    cout << "\nYou chose Intel/AMD PC.\n";
                    flag2 = true;
                    break;

                case 2:
                    cout << "\nYou chose Intel/AMD Laptop.\n";
                    flag2 = true;
                    break;

                case 3:
                    cout << "\nYou chose Intel/AMD Phone.\n";
                    flag2 = true;
                    break;

                case 4:
                    cout << "\nYou chose Intel/AMD Tablet.\n";
                    flag2 = true;
                    break;

                default:
                    cout << "\nInvalid choice...  Please choose a valid option!\n";
                    cout << " 1. Intel / AMD\n ";
                    cout << "2. Apple\n\n";

                    break;
                }
            }

            cout << "Now please fill in the requirements form for your chosen device.\n";
            comp.InputComputer();
            flag = true; // Exiting the outer loop
            break;
        }

        case 2:// if the user chooses Mac
        {
            bool flag3 = false;
            int Choice2;

            cout << "\nChoose one of the following Apple devices:\n";
            cout << "1. iPad\n";
            cout << "2. Mac\n";
            cout << "3. iMac\n";
            cout << "4. iPhone\n\n";

            while (!flag3)
            {
                cout << "Enter your choice (1-4): ";

                // if the input is an alphabet
                if (!(cin >> Choice2))
                {
                    cout << "\nInvalid input! Please enter an integer not an alphabet...\n";

                    cin.clear(); // clears the inputted data for new data to get inputted

                    while (cin.get() != '\n') // discards data until \n
                    {
                        continue; // continues tll it reaches a \n
                    }

                    continue; // for inputting again
                }

                switch (Choice2)
                {
                case 1:
                    cout << "\nYou chose Apple iPad.\n";
                    flag3 = true;
                    break;

                case 2:
                    cout << "\nYou chose Apple Mac.\n";
                    flag3 = true;
                    break;

                case 3:
                    cout << "\nYou chose Apple iMac.\n";
                    flag3 = true;
                    break;

                case 4:
                    cout << "\nYou chose Apple iPhone.\n";
                    flag3 = true;
                    break;

                default:
                    cout << "\nInvalid choice... Please enter a number between 1 and 4.\n";
                    break;
                }
            }
            cout << "Now please fill in the requirements form for your chosen device.\n";
            comp.InputComputerForMac();
            flag = true; // Exiting the outer loop
            break;
        }

        default:
            cout << "\nInvalid choice...  Please choose a valid option!\n";
            cout << " 1. Intel / AMD\n ";
            cout << "2. Apple\n\n";
            break;
        }
    }

    comp.DisplayComputer();

    return 0;
}