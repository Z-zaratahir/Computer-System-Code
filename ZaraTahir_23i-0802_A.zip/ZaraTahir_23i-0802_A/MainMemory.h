#pragma once
#include <iostream>
#include "../oop_a3/PhysicalMemory.h"
using namespace std;


class MainMemory : public PhysicalMemory
{

    string technologyType;
    double price = 100.0;

public:
    MainMemory()
        : technologyType(" "), price(0) {}

    MainMemory(int capacity, string TechnologyType, double Price)
        : PhysicalMemory(capacity),
        technologyType(TechnologyType), price(Price) {}

    string gettechnologyType()
    {
        return technologyType;
    }

    void settechnologyType(string technologyType)
    {
        this->technologyType = technologyType;
    }

    double GetPrice()
    {
        return price;
    }

    void SetPrice(double myPrice)
    {

        price = myPrice;
    }

    void InputMainMemory()
    {
        cout << "\nMAIN MEMORY: \n-------------\n";
        cout << "\nEnter the capacity of main memory (4/8/16/32/64) GB: ";
        cin >> capacity;

        // invalid input
        while (capacity != 16 && capacity != 32 && capacity != 64 && capacity != 8 && capacity != 4)
        {
            cout << "Invalid input! Please enter a valid input...  ";
            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n');// discards data until \n

            cin >> capacity;
        }

        int picked;
        while (true)
        {
            cout << "\nSelect one of the following technology types:  ";

            cout << "\n\n1. Silicon" << endl;
            cout << "2. Semiconductor\n\n"
                << endl;

            cout << "Selected:  ";


            // if the input is an alphabet
            if (!(cin >> picked))
            {
                cout << "\nInvalid input! Please enter an integer not an alphabet...\n";

                cin.clear(); // clears the inputted data for new data to get inputted

                while (cin.get() != '\n') // discards data until \n
                {
                    continue; // continues tll it reaches a \n
                }

                continue; // for inputting again
            }

            switch (picked)
            {
            case 1:
                technologyType = "silicon";
                price = 100.0;
                return; // Exit the function after valid input
            case 2:
                technologyType = "semiconductor";
                price = 100.0;
                return;
            default:
                cout << "It's an invalid choice...Please choose a valid option.\n"
                    << endl;

                break; // Ask for input again in case of invalid choice
            }
        }
    }



    void InputMainMemoryForMac()
    {
        cout << "\nMAIN MEMORY: \n-------------\n";
        cout << "\nEnter the capacity of main memory (8/16/32/64) GB: ";
        cin >> capacity;

        // invalid input
        while (capacity != 16 && capacity != 32 && capacity != 64 && capacity != 8)
        {
            cout << "Invalid input! Please enter a valid input...  ";
            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n');// discards data until \n

            cin >> capacity;
        }

        int picked;
        while (true)
        {
            cout << "\nSelect one of the following technology types:  ";

            cout << "\n\n1. Silicon" << endl;
            cout << "2. Semiconductor\n\n"
                << endl;

            cout << "Selected:  ";


            // if the input is an alphabet
            if (!(cin >> picked))
            {
                cout << "\nInvalid input! Please enter an integer not an alphabet...\n";

                cin.clear(); // clears the inputted data for new data to get inputted

                while (cin.get() != '\n') // discards data until \n
                {
                    continue; // continues tll it reaches a \n
                }

                continue; // for inputting again
            }

            switch (picked)
            {
            case 1:
                technologyType = "silicon";
                price = 100.0;
                return; // Exit the function after valid input
            case 2:
                technologyType = "semiconductor";
                price = 100.0;
                return;
            default:
                cout << "It's an invalid choice...Please choose a valid option.\n"
                    << endl;

                break; // Ask for input again in case of invalid choice
            }
        }
    }

    void DisplayMainMemory()
    {
        cout << "\nMAIN MEMORY DETAILS: \n-------------\n\n";
        cout << "Technology Type is " << technologyType << " having a capacity of " << capacity << " GB" << endl;
    }
};
