#pragma once
#include <iostream>
#include "../oop_a3/PhysicalMemory.h"
using namespace std;


class StorageDevice : public PhysicalMemory
{

    string type;
    double price;

public:
    StorageDevice()
        : type(" "),
        price(0.0) {}

    StorageDevice(int capacity, string myType, double myPrice)
        : PhysicalMemory(capacity),
        type(myType),
        price(myPrice) {}

    string GetType()
    {
        return type;
    }

    void SetType(string myType)
    {
        type = myType;
    }

    double GetPrice()
    {
        return price;
    }

    void SetPrice(double myPrice)
    {

        price = myPrice;
    }
    void InputStorageDevice()
    {
        cout << "\nSTORAGE DEVICE: \n-------------\n";

        bool flag = false;
        int picked;

        while (true)
        {

            cout << "\nSelect one of the following types of storage device: " << endl
                << endl;
            cout << "1. HDD  - Hard Disk Drive" << endl;
            cout << "2. SSD  - Solid State Drive" << endl;
            cout << "3. NVMe - Non-Volatile Memory Express" << endl
                << endl;

            cout << "\nSelected: ";


            // if the input is an alphabet
            if (!(cin >> picked))
            {
                cout << "\nInvalid input! Please enter an integer not an alphabet...\n";

                cin.clear(); // clears the inputted data for new data to get inputted

                while (cin.get() != '\n') // discards data until \n
                {
                    continue; // continues tll it reaches a \n
                }

                continue; // for inputting again
            }

            switch (picked)
            {
            case 1:
                type = "HDD";
                price = 60.0;
                flag = true;
                break;

            case 2:
                type = "SSD";
                price = 100.0;
                flag = true;
                break;

            case 3:
                type = "NVMe";
                price = 200.0;
                flag = true;
                break;

            default:
                cout << "It's an invalid choice...Please choose a valid option." << endl;
                break;
            }

            if (flag)
            {
                break;
            }
        }

        cout << "\nEnter the capacity of storage device (4/8/16/32/64) : ";
        cin >> capacity;


        // invalid input
        while (capacity != 16 && capacity != 32 && capacity != 64 && capacity != 8 && capacity != 4)
        {
            cout << "Invalid input! Please enter a valid input...  ";
            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n');// discards data until \n

            cin >> capacity;
        }

        // cout << "\nEnter the price of the storage device: $";
        // cin >> price;
    }


    void InputStorageDeviceForMac()
    {
        cout << "\nSTORAGE DEVICE: \n-------------\n";

        bool flag = false;
        int picked;

        while (true)
        {

            cout << "\nSelect one of the following types of storage device: " << endl
                << endl;
            cout << "1. HDD  - Hard Disk Drive" << endl;
            cout << "2. SSD  - Solid State Drive" << endl;
            cout << "3. NVMe - Non-Volatile Memory Express" << endl
                << endl;

            cout << "\nSelected: ";


            // if the input is an alphabet
            if (!(cin >> picked))
            {
                cout << "\nInvalid input! Please enter an integer not an alphabet...\n";

                cin.clear(); // clears the inputted data for new data to get inputted

                while (cin.get() != '\n') // discards data until \n
                {
                    continue; // continues tll it reaches a \n
                }

                continue; // for inputting again
            }

            switch (picked)
            {
            case 1:
                type = "HDD";
                price = 60.0;
                flag = true;
                break;

            case 2:
                type = "SSD";
                price = 100.0;
                flag = true;
                break;

            case 3:
                type = "NVMe";
                price = 200.0;
                flag = true;
                break;

            default:
                cout << "It's an invalid choice...Please choose a valid option." << endl;
                break;
            }

            if (flag)
            {
                break;
            }
        }

        cout << "\nEnter the capacity of storage device (8/16/32/64) GB: ";
        cin >> capacity;


        // invalid input
        while (capacity != 16 && capacity != 32 && capacity != 64 && capacity != 8)
        {
            cout << "Invalid input! Please enter a valid input...  ";
            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n');// discards data until \n

            cin >> capacity;
        }

        // cout << "\nEnter the price of the storage device: $";
        // cin >> price;
    }


    void DisplayStorageDevice()
    {
        cout << "\nSTORAGE DEVICE DETAILS: \n-------------\n\n";
        cout << "Storage Device is " << type << " with a capacity of " << capacity << " GB" << endl;
    }
};

