#pragma once
#include "../oop_a3/Computer.h"

using namespace std;

class APPLE : public Computer
{
public:

    APPLE() :Computer() {}

};