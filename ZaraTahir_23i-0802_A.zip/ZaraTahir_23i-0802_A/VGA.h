#pragma once
#include "../oop_a3/Port.h"

class VGA : public Port
{
public:

	VGA() : Port(0.0, " ", 0) {}

	VGA(double myPrice, string myType, int myBaudRate)
		: Port(myPrice, myType, myBaudRate) {}
};