#pragma once
#include "../oop_a3/Computer.h"

using namespace std;

class IntelAMD : public Computer
{
public:

    IntelAMD() :Computer(){}

};
  