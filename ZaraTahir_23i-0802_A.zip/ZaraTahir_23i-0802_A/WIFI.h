#pragma once
#include "../oop_a3/NetworkCard.h"

class WIFI : public NetworkCard
{
public:
    WIFI() : NetworkCard(" ", 0, 0.0) {} // Default constructor

    WIFI(int mySpeed, double myPrice)
        : NetworkCard(" ", mySpeed, myPrice) {} // Parameterized constructor
};