#pragma once
#include <iostream>
#include "../oop_a3/ComputerAssembly.h"
using namespace std;


class Computer
{

    ComputerAssembly assembly;

public:
    void InputComputer()
    {
        assembly.InputCompuerAssembly();
    }

    void InputComputerForMac()
    {
        assembly.InputCompuerAssemblyForMac();
    }

    void DisplayComputer()
    {

        cout << "\n\n\n\n                                                  COMPUTER SPECIFICATIONS\n\n";
        cout << "                                                  -----------------------\n\n";
        assembly.DisplayComputerAssembly();
    }

    // ~Computer()
    // {
    //     delete assembly.GetMotherBoard();
    //     delete assembly.GetBattery();
    // }
};
