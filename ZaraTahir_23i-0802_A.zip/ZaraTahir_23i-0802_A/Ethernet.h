#pragma once
#include "../oop_a3/NetworkCard.h"

class EthernetCard : public NetworkCard
{
public:
    EthernetCard() : NetworkCard(" ", 0, 0.0) {} // Default constructor

    EthernetCard(int mySpeed, double myPrice)
        : NetworkCard(" ", mySpeed, myPrice) {} // Parameterized constructor
};