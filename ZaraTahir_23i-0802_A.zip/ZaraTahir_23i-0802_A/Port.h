#pragma once
#include <iostream>
using namespace std;

class Port
{
    double price;

protected:
    string type;
    int baud_rate;

public:
    Port()
        : price(0), type(" "),
        baud_rate(0) {}

    Port(double Price, string myType, int myBaudRate)
        : price(Price), type(myType),
        baud_rate(myBaudRate) {}

    string GetType()
    {
        return type;
    }

    void SetType(string myType)
    {
        type = myType;
    }

    int GetBaudRate()
    {

        return baud_rate;
    }

    void SetBaudRate(int myBaudRate)
    {

        baud_rate = myBaudRate;
    }

    double GetPrice()
    {
        return price;
    }

    void SetPrice(double myPrice)
    {

        price = myPrice;
    }

    void InputPort()
    {

        // cout << "Enter the type of port: ";
        // cin >> type;

        // cout << "Enter the baud rate of the port: ";
        // cin >> baud_rate;

        cout << "Choose between the following types of port:" << endl
            << endl;

        cout << "1. VGA Port" << endl;

        cout << "2. HDMI Port" << endl;

        cout << "3. USB Port" << endl;

        cout << "4. AUX Port" << endl;

        cout << "5. I/O Port" << endl;

        int picked;
        // cout << "\nEnter your choice: ";
        // cin >> picked;

        bool flag = false;

        while (!flag)
        {
            cout << "\nSelecting: ";
            cin >> picked;

            switch (picked)
            {
            case 1:
                type = "VGI";
                price = 15.0;
                flag = true;
                break;

            case 2:
                type = "HDMI";
                price = 10.0;
                flag = true;
                break;

            case 3:
                type = "USB";
                price = 25.0;
                flag = true;
                break;

            case 4:
                type = "AUX";
                price = 20.0;
                flag = true;
                break;

            case 5:
                type = "I/O";
                price = 20.0;
                flag = true;
                break;

            default:
                cout << "\nInvalid choice... Please choose a valid option." << endl;
                break;
            }
        }

        cout << "Enter the baud rate of the port (9600 - 115200) bps: ";




        //invalid input
        while (!(cin >> baud_rate) || baud_rate < 9600 || baud_rate > 115200)
        {
            cout << "Invalid input! Please enter a valid input...  ";
            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n')// discards data until \n
            {
                continue;
            }

        }



    }

    void DisplayPorts()
    {
       

        cout << "\n"
            << type << ", Baud Rate: " << baud_rate << " bps" << endl;
    }
};
