#pragma once
#include <iostream>
#include "../oop_a3/MotherBoard.h"
#include "../oop_a3/Battery.h"
#include "../oop_a3/Case.h"
class ComputerAssembly
{

    double totalPrice;
    MotherBoard* mmm;
    Battery* b;
    Case c;

public:
    ComputerAssembly()
        : totalPrice(0.0), mmm(new MotherBoard()), b(new Battery()) {}

    ComputerAssembly(double myTotalPrice)
        : totalPrice(myTotalPrice), mmm(new MotherBoard()), b(new Battery()) {}

    double GetTotalPrice()
    {
        return totalPrice;
    }

    void SetTotalPrice(double myTotalPrice)
    {
        totalPrice = myTotalPrice;
    }

    MotherBoard* GetMotherBoard()
    {
        return mmm;
    }

    void SetMotherBoard(MotherBoard* myMM)
    {
        mmm = myMM;
    }

    Battery* GetBattery()
    {
        return b;
    }

    void SetBattery(Battery* myB)
    {
        b = myB;
    }

    Case GetCase()
    {
        return c;
    }

    void SetCase(const Case& myCase)
    {
        c = myCase;
    }

    double CalculateTotalPrice()
    {
        totalPrice = mmm->sumOfPrice() + b->GetPrice() + c.GetPrice();
        return totalPrice;
    }

    void InputCompuerAssembly()
    {
        mmm->InputMotherBoard();

        b->InputBattery();
        c.InputCase();
    }


    void InputCompuerAssemblyForMac()
    {
        mmm->InputMotherBoardForMac();

        b->InputBatteryForMac();
        c.InputCase();
    }

    void DisplayComputerAssembly()
    {
        mmm->DisplayMotherBoard();
        b->DisplayBattery();
        c.DisplayCase();
        cout << "\n\n\nThe total cost sums upto $ " << CalculateTotalPrice() << endl;
    }

    ~ComputerAssembly()
    {
        delete mmm; // Free the memory allocated for MotherBoard
        delete b;   // Free the memory allocated for Battery
    }
};

