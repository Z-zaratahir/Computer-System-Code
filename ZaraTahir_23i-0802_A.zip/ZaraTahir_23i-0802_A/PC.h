#pragma once
#include "../oop_a3/IntelAMD.h"

using namespace std;

class PC : public IntelAMD
{
public:

    PC() :IntelAMD() {}

};