#pragma once
#include <iostream>
using namespace std;


class Case
{
    double price;

    string formFactor;
    string color;

public:
    Case()
        : price(0.0), formFactor(" "),
        color(" ") {}

    Case(double Price, string myFormFactor, string myColor)
        : price(Price), formFactor(myFormFactor),
        color(myColor) {}

    string GetFormFactor()
    {
        return formFactor;
    }

    void SetFormFactor(string myFormFactor)
    {
        formFactor = myFormFactor;
    }

    string GetColor()
    {
        return color;
    }

    void SetColor(string myColor)
    {
        color = myColor;
    }

    double GetPrice()
    {
        return price;
    }

    void SetPrice(double myPrice)
    {

        price = myPrice;
    }

    void InputCase()
    {
        cout << "\n\n---CASE REQUIREMENTS---\n\n";
        int picked;

        bool flag = false;
        while (!flag)
        {

            cout << "\nSelect one of the following form factors of the case: ";

            cout << "\n\n1. ATX" << endl;

            cout << "2. Micro ATX\n"
                << endl;
            cout << "Selecting: ";

            // if the input is an alphabet
            if (!(cin >> picked))
            {
                cout << "\nInvalid input! Please enter an integer not an alphabet...\n";

                cin.clear();// clears the inputted data for new data to get inputted

                while (cin.get() != '\n')// discards data until \n 
                {
                    continue;// continues tll it reaches a \n
                }

                continue;// for inputting again
            }

            switch (picked)
            {
            case 1:
                formFactor = "ATX";
                price = 100;
                flag = true;
                break;

            case 2:
                formFactor = "Micro ATX";
                price = 70;
                flag = true;
                break;

            default:
                cout << "\nInvalid choice. Please choose a valid option.\n"
                    << endl;
                break;
            }
        }

        cout << "\nEnter the color of the case: ";
        cin.ignore();
        getline(cin, color);
    }

    void DisplayCase()
    {
        cout << "\nCASE DETAILS: \n-------------\n\n";
        cout << "Form Factor: " << formFactor << endl;
        cout << "Color: " << color << endl;
    }
};
