#pragma once
#include "../oop_a3/IntelAMD.h"

using namespace std;

class PHONES : public IntelAMD
{
public:

    PHONES() :IntelAMD() {}

};