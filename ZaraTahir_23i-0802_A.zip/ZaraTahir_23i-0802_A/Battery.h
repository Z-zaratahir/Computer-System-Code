#pragma once
#include <iostream>
#include "../oop_a3/PowerSupply.h"
using namespace std;


class Battery : public PowerSupply
{

    int capacity;

public:
    Battery()
        : PowerSupply(), capacity(0) {}

    Battery(int Capacity)
        : capacity(Capacity) {}

    int GetCapacity()
    {

        return capacity;
    }

    void SetCapacity(int Capacity)
    {

        capacity = Capacity;
    }

    void InputBattery()
    {
        cout << "\n\n---BATTERY REQUIREMENTS---\n\n";
        cout << "Enter the capacity of Battery (3000 mAh - 7000 mAh):  ";
        // cin >> capacity;


         //invalid input
        while (!(cin >> capacity) || capacity < 3000 || capacity > 7000)
        {
            cout << "Invalid input! Please enter a valid input...  ";
            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n')// discards data until \n
            {
                continue;
            }
            //  cin >> capacity;
        }

    }


    void InputBatteryForMac()
    {
        cout << "\n\n---BATTERY REQUIREMENTS---\n\n";
        cout << "Enter the capacity of Battery (4000 mAh - 9000 mAh):  ";
        //cin >> capacity;


        //invalid input
        while (!(cin >> capacity) || capacity < 4000 || capacity > 9000)
        {
            cout << "Invalid input! Please enter a valid input...  ";
            cin.clear();// clears the inputted data for new data to get inputted

            while (cin.get() != '\n')// discards data until \n
            {
                continue;
            }
            cin >> capacity;
        }

    }


    void DisplayBattery()
    {
        cout << "\nBATTERY DETAILS: \n-------------\n\n";
        cout << "Battery Capacity: " << capacity << " mAh" << endl;
    }
};
