#pragma once
#include <iostream>
#include "../oop_a3/ALU.h"
#include "../oop_a3/ControlUnit.h"
using namespace std;


class CPU
{
    double price = 300.0;

protected:
    ALU alu;
    ControlUnit cu;

public:
    CPU()
        : price(300.0), alu(0, 0, 0, 0),
        cu(0) {}

    CPU(int NoOfAdders,
        int NoOfSubtractor,
        int NoOfRegisters,
        int sizeOfRegisters,
        float theClock, int Price)

        : alu(NoOfAdders, NoOfSubtractor, NoOfRegisters, sizeOfRegisters),
        cu(theClock), price(Price)
    {
    }

    int GetNoOfAdders()
    {
        return alu.getNoOfAdders();
    }

    void SetNoOfAdders(int NoOfAdders)
    {
        alu.setNoOfAdders(NoOfAdders);
    }

    int GetNoOfSubtractor()
    {
        return alu.getNoOfSubtractor();
    }

    void SetNoOfSubtractor(int NoOfSubtractor)
    {

        alu.setNoOfSubtractor(NoOfSubtractor);
    }

    int GetNoOfRegisters()
    {
        return alu.getNoOfRegisters();
    }
    void SetNoOfRegisters(int NoOfRegisters)
    {
        alu.setNoOfRegisters(NoOfRegisters);
    }

    int GetSizeOfRegisters()
    {
        return alu.getSizeOfRegisters();
    }

    void SetsizeOfRegisters(int sizeOfRegisters)
    {
        alu.setsizeOfRegisters(sizeOfRegisters);
    }

    float Getclock()
    {
        return cu.getclock();
    }

    void Setclock(float theClock)
    {

        cu.setclock(theClock);
    }

    double GetPrice()
    {
        return price;
    }

    void SetPrice(double myPrice = 300.0)
    {

        price = myPrice;
    }

    void InputCPU()
    {
        cout << "\n\n---CPU REQUIREMENTS---\n\n";
        alu.input();
        cu.inputClock();
    }

    void InputCPUForMac()
    {
        cout << "\n\n---CPU REQUIREMENTS---\n\n";
        alu.InputForMac();
        cu.inputClockForMac();
    }

    void DisplayCPU()
    {
        //cout << "\n\n---CPU SPECIFICATIONS---\n\n";
        alu.displayALU();
        cu.displayclock();
    }
};
